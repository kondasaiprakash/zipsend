from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.Keys import Keys
import os

# chrome_options = Options()
# chrome_options.add_argument('--headless')
# chrome_options.add_argument('--no-sandbox')
# chrome_options.add_argument('--disable-gpu')
# chrome_options.add_argument('--window-size=1280x1696')
# chrome_options.add_argument('--user-data-dir=/tmp/user-data')
# chrome_options.add_argument('--hide-scrollbars')
# chrome_options.add_argument('--enable-logging')
# chrome_options.add_argument('--log-level=0')
# chrome_options.add_argument('--v=99')
# chrome_options.add_argument('--single-process')
# chrome_options.add_argument('--data-path=/tmp/data-path')
# chrome_options.add_argument('--ignore-certificate-errors')
# chrome_options.add_argument('--homedir=/tmp')
# chrome_options.add_argument('--disk-cache-dir=/tmp/cache-dir')
# chrome_options.add_argument('user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36')
# chrome_options.binary_location = os.getcwd() + "/bin/headless-chromium"

# driver = webdriver.Chrome(chrome_options=chrome_options)

def lambda_handler(event, context):
    # TODO implement
    print("Starting google.com")
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument('--window-size=1280x1696')
    chrome_options.add_argument('--user-data-dir=/tmp/user-data')
    chrome_options.add_argument('--hide-scrollbars')
    chrome_options.add_argument('--enable-logging')
    chrome_options.add_argument('--log-level=0')
    chrome_options.add_argument('--v=99')
    chrome_options.add_argument('--single-process')
    chrome_options.add_argument('--data-path=/tmp/data-path')
    chrome_options.add_argument('--ignore-certificate-errors')
    chrome_options.add_argument('--homedir=/tmp')
    chrome_options.add_argument('--disk-cache-dir=/tmp/cache-dir')
    chrome_options.add_argument('user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36')
    chrome_options.binary_location = os.getcwd() + "/bin/headless-chromium"

    driver = webdriver.Chrome(chrome_options=chrome_options)
    driver.get("http://lms.bmu.edu.in/")
    # driver.maximize_window()
    # username = driver.find_element_by_id("yui_3_17_2_1_1554829476833_75")
    username = driver.find_element_by_name("username")
    password = driver.find_element_by_id("password")
    username.send_keys("malneni.asish.16ece")
    password.send_keys("As@54995")
    password.send_keys(Keys.RETURN)
    print("end")
    # driver.find_element_by_class_name("panel-title")
    driver.get("http://lms.bmu.edu.in/mod/attendance/myattendance.php?studentid=2380")
    course_names = driver.find_elements_by_class_name("panel-title")
    cp = driver.find_elements_by_class_name("attendance-report-wrapper")
    count = 0
    final = list()
    for i in cp:
        k = i.find_elements_by_tag_name("tbody")
        for j in k:
            td = j.find_elements_by_tag_name("td")
            #         print(td[8].text)
            #         print(td[5].text)
            tup = (str(course_names[count].text), str(td[5].text), str(td[8].text))
            final.append(tup)
            count = count + 1
            print(tup)
    return tup
   
